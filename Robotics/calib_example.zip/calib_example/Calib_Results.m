% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 3405.596599993778455 ; 3433.785271933498734 ];

%-- Principal point:
cc = [ 2015.223436179238206 ; 1419.491785075294956 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ 0.068034526004941 ; -0.141130769673915 ; -0.003826330538507 ; -0.002222958658656 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 13.549925980071684 ; 12.811535949184552 ];

%-- Principal point uncertainty:
cc_error = [ 17.959949041270367 ; 16.400758434294616 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.011801306441103 ; 0.043422901113251 ; 0.001866303996943 ; 0.002070833835487 ; 0.000000000000000 ];

%-- Image size:
nx = 4032;
ny = 3024;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 20;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ -2.199204e+00 ; -2.173159e+00 ; 9.996310e-02 ];
Tc_1  = [ -7.905404e+01 ; -6.341969e+01 ; 3.695415e+02 ];
omc_error_1 = [ 4.560087e-03 ; 4.889047e-03 ; 1.025034e-02 ];
Tc_error_1  = [ 1.961451e+00 ; 1.772932e+00 ; 1.609875e+00 ];

%-- Image #2:
omc_2 = [ -1.926549e+00 ; -1.868712e+00 ; -8.953844e-01 ];
Tc_2  = [ -1.133829e+02 ; 9.197863e+00 ; 3.788269e+02 ];
omc_error_2 = [ 3.640890e-03 ; 5.338573e-03 ; 7.757128e-03 ];
Tc_error_2  = [ 1.997020e+00 ; 1.845550e+00 ; 1.886510e+00 ];

%-- Image #3:
omc_3 = [ -2.142784e+00 ; -2.082573e+00 ; 9.289691e-02 ];
Tc_3  = [ -2.333903e+02 ; -3.665651e+01 ; 4.646981e+02 ];
omc_error_3 = [ 6.055143e-03 ; 5.260848e-03 ; 1.075096e-02 ];
Tc_error_3  = [ 2.511488e+00 ; 2.361445e+00 ; 2.243614e+00 ];

%-- Image #4:
omc_4 = [ -1.597326e+00 ; -1.581199e+00 ; 3.946902e-02 ];
Tc_4  = [ -1.792559e+02 ; -4.951960e+01 ; 4.689392e+02 ];
omc_error_4 = [ 4.475342e-03 ; 4.625407e-03 ; 6.011115e-03 ];
Tc_error_4  = [ 2.501973e+00 ; 2.310115e+00 ; 1.988282e+00 ];

%-- Image #5:
omc_5 = [ -2.003774e+00 ; -1.929771e+00 ; -4.671128e-01 ];
Tc_5  = [ -1.556270e+02 ; -2.408506e+01 ; 5.512996e+02 ];
omc_error_5 = [ 4.698870e-03 ; 5.568279e-03 ; 9.695195e-03 ];
Tc_error_5  = [ 2.910479e+00 ; 2.682658e+00 ; 2.641998e+00 ];

%-- Image #6:
omc_6 = [ -1.847192e+00 ; -1.766506e+00 ; 7.454417e-01 ];
Tc_6  = [ -1.616444e+02 ; -5.242567e+01 ; 4.700250e+02 ];
omc_error_6 = [ 5.335713e-03 ; 3.945598e-03 ; 6.728504e-03 ];
Tc_error_6  = [ 2.515055e+00 ; 2.309031e+00 ; 1.680923e+00 ];

%-- Image #7:
omc_7 = [ 1.578630e+00 ; 1.403070e+00 ; -2.234294e-01 ];
Tc_7  = [ -7.013849e+01 ; -5.301438e+01 ; 4.622271e+02 ];
omc_error_7 = [ 4.380463e-03 ; 4.550164e-03 ; 5.813092e-03 ];
Tc_error_7  = [ 2.437077e+00 ; 2.203707e+00 ; 1.849451e+00 ];

%-- Image #8:
omc_8 = [ 2.059245e+00 ; 2.042539e+00 ; 3.247956e-01 ];
Tc_8  = [ -1.037526e+02 ; -5.885341e+01 ; 2.852086e+02 ];
omc_error_8 = [ 4.321814e-03 ; 3.638447e-03 ; 8.112205e-03 ];
Tc_error_8  = [ 1.544441e+00 ; 1.403556e+00 ; 1.284940e+00 ];

%-- Image #9:
omc_9 = [ -1.576628e+00 ; -1.878763e+00 ; -1.244337e+00 ];
Tc_9  = [ 1.246953e+01 ; -3.274673e+01 ; 3.442087e+02 ];
omc_error_9 = [ 3.043796e-03 ; 5.962069e-03 ; 7.003347e-03 ];
Tc_error_9  = [ 1.828446e+00 ; 1.652053e+00 ; 1.696152e+00 ];

%-- Image #10:
omc_10 = [ 1.833416e+00 ; 1.794103e+00 ; 5.761017e-01 ];
Tc_10  = [ -2.413911e+01 ; -7.544954e+01 ; 2.745614e+02 ];
omc_error_10 = [ 4.888648e-03 ; 3.695195e-03 ; 6.993398e-03 ];
Tc_error_10  = [ 1.465903e+00 ; 1.301626e+00 ; 1.204827e+00 ];

%-- Image #11:
omc_11 = [ 1.918450e+00 ; 1.907369e+00 ; -1.858470e-01 ];
Tc_11  = [ -1.311196e+02 ; -1.178043e+02 ; 4.783599e+02 ];
omc_error_11 = [ 3.976303e-03 ; 5.320147e-03 ; 8.474250e-03 ];
Tc_error_11  = [ 2.552850e+00 ; 2.324234e+00 ; 2.057736e+00 ];

%-- Image #12:
omc_12 = [ -2.162903e+00 ; -2.142194e+00 ; 1.662527e-01 ];
Tc_12  = [ -7.950126e+01 ; -7.485723e+01 ; 4.077992e+02 ];
omc_error_12 = [ 5.024706e-03 ; 5.174329e-03 ; 1.070844e-02 ];
Tc_error_12  = [ 2.158517e+00 ; 1.951107e+00 ; 1.737398e+00 ];

%-- Image #13:
omc_13 = [ -1.923764e+00 ; -1.862255e+00 ; -9.040078e-01 ];
Tc_13  = [ -1.128073e+02 ; 1.001568e+01 ; 3.752834e+02 ];
omc_error_13 = [ 3.636491e-03 ; 5.337905e-03 ; 7.718619e-03 ];
Tc_error_13  = [ 1.978359e+00 ; 1.828490e+00 ; 1.871194e+00 ];

%-- Image #14:
omc_14 = [ -1.268249e+00 ; -1.680133e+00 ; 8.021362e-01 ];
Tc_14  = [ -2.193723e+01 ; -8.630472e+01 ; 4.670607e+02 ];
omc_error_14 = [ 4.556198e-03 ; 4.623270e-03 ; 5.346261e-03 ];
Tc_error_14  = [ 2.455067e+00 ; 2.226116e+00 ; 1.428002e+00 ];

%-- Image #15:
omc_15 = [ 1.545001e+00 ; 2.437362e+00 ; -4.065068e-01 ];
Tc_15  = [ -1.143210e+02 ; -1.572367e+02 ; 5.398000e+02 ];
omc_error_15 = [ 3.030097e-03 ; 6.587842e-03 ; 9.670701e-03 ];
Tc_error_15  = [ 2.891887e+00 ; 2.627194e+00 ; 2.170502e+00 ];

%-- Image #16:
omc_16 = [ -1.861762e+00 ; -1.840188e+00 ; 8.554359e-02 ];
Tc_16  = [ -7.397843e+01 ; -2.222232e+00 ; 5.336319e+02 ];
omc_error_16 = [ 4.191991e-03 ; 5.436043e-03 ; 8.169046e-03 ];
Tc_error_16  = [ 2.807879e+00 ; 2.552220e+00 ; 2.070150e+00 ];

%-- Image #17:
omc_17 = [ -1.484084e+00 ; -1.837553e+00 ; 4.536971e-01 ];
Tc_17  = [ -7.435207e+01 ; -1.016881e+02 ; 4.993056e+02 ];
omc_error_17 = [ 4.661999e-03 ; 4.609285e-03 ; 6.354721e-03 ];
Tc_error_17  = [ 2.641238e+00 ; 2.391815e+00 ; 1.949906e+00 ];

%-- Image #18:
omc_18 = [ -9.075078e-01 ; -2.018464e+00 ; 3.758826e-01 ];
Tc_18  = [ -2.006097e+01 ; -1.423397e+02 ; 5.120601e+02 ];
omc_error_18 = [ 4.121228e-03 ; 5.173550e-03 ; 5.969557e-03 ];
Tc_error_18  = [ 2.728767e+00 ; 2.448903e+00 ; 2.203805e+00 ];

%-- Image #19:
omc_19 = [ -2.139777e+00 ; -2.076346e+00 ; 1.211489e-01 ];
Tc_19  = [ -2.318234e+02 ; -3.766839e+01 ; 4.651848e+02 ];
omc_error_19 = [ 6.017931e-03 ; 5.170924e-03 ; 1.053730e-02 ];
Tc_error_19  = [ 2.515938e+00 ; 2.361667e+00 ; 2.219949e+00 ];

%-- Image #20:
omc_20 = [ -2.362301e+00 ; -1.589260e+00 ; 1.360828e+00 ];
Tc_20  = [ -1.656961e+02 ; -1.470227e+01 ; 5.422089e+02 ];
omc_error_20 = [ 6.801566e-03 ; 2.854913e-03 ; 7.752547e-03 ];
Tc_error_20  = [ 2.893855e+00 ; 2.646462e+00 ; 1.929624e+00 ];

