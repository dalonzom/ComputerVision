% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 3368.080067061492628 ; 3396.503196454924364 ];

%-- Principal point:
cc = [ 1986.682668166477470 ; 1412.868265848865121 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ 0.070400004528709 ; -0.148303239473752 ; -0.005516427826902 ; -0.005726841116948 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 25.866569280901160 ; 24.604971123669610 ];

%-- Principal point uncertainty:
cc_error = [ 34.556631561876316 ; 29.976132800359760 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.024427721678915 ; 0.093378938768651 ; 0.003424124653429 ; 0.004009857828028 ; 0.000000000000000 ];

%-- Image size:
nx = 4032;
ny = 3024;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 16;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ -2.196959e+00 ; -2.171414e+00 ; 1.113881e-01 ];
Tc_1  = [ -7.590955e+01 ; -6.273097e+01 ; 3.659955e+02 ];
omc_error_1 = [ 8.370989e-03 ; 9.001872e-03 ; 1.873631e-02 ];
Tc_error_1  = [ 3.778414e+00 ; 3.239122e+00 ; 3.001832e+00 ];

%-- Image #2:
omc_2 = [ -1.930185e+00 ; -1.866488e+00 ; -8.815386e-01 ];
Tc_2  = [ -1.102184e+02 ; 9.889157e+00 ; 3.753377e+02 ];
omc_error_2 = [ 6.624937e-03 ; 1.004165e-02 ; 1.482768e-02 ];
Tc_error_2  = [ 3.846433e+00 ; 3.368089e+00 ; 3.531003e+00 ];

%-- Image #3:
omc_3 = [ -2.141552e+00 ; -2.078772e+00 ; 1.069252e-01 ];
Tc_3  = [ -2.294601e+02 ; -3.558390e+01 ; 4.618682e+02 ];
omc_error_3 = [ 1.140615e-02 ; 1.020829e-02 ; 1.984306e-02 ];
Tc_error_3  = [ 4.871765e+00 ; 4.308867e+00 ; 4.191596e+00 ];

%-- Image #4:
omc_4 = [ -1.598494e+00 ; -1.576537e+00 ; 4.695415e-02 ];
Tc_4  = [ -1.753814e+02 ; -4.849138e+01 ; 4.653326e+02 ];
omc_error_4 = [ 8.265267e-03 ; 8.891246e-03 ; 1.123132e-02 ];
Tc_error_4  = [ 4.835164e+00 ; 4.219062e+00 ; 3.689189e+00 ];

%-- Image #5:
omc_5 = [ -2.004390e+00 ; -1.925332e+00 ; -4.557260e-01 ];
Tc_5  = [ -1.508617e+02 ; -2.296557e+01 ; 5.456618e+02 ];
omc_error_5 = [ 8.451209e-03 ; 1.034811e-02 ; 1.815263e-02 ];
Tc_error_5  = [ 5.601437e+00 ; 4.891104e+00 ; 4.923931e+00 ];

%-- Image #6:
omc_6 = [ -1.844306e+00 ; -1.762334e+00 ; 7.529016e-01 ];
Tc_6  = [ -1.578644e+02 ; -5.149346e+01 ; 4.670214e+02 ];
omc_error_6 = [ 1.016840e-02 ; 7.576478e-03 ; 1.226242e-02 ];
Tc_error_6  = [ 4.856583e+00 ; 4.217950e+00 ; 3.118867e+00 ];

%-- Image #7:
omc_7 = [ 1.577409e+00 ; 1.409023e+00 ; -2.338473e-01 ];
Tc_7  = [ -6.626263e+01 ; -5.208598e+01 ; 4.580075e+02 ];
omc_error_7 = [ 8.155735e-03 ; 8.798279e-03 ; 1.084204e-02 ];
Tc_error_7  = [ 4.699578e+00 ; 4.029238e+00 ; 3.435884e+00 ];

%-- Image #8:
omc_8 = [ 2.062463e+00 ; 2.046093e+00 ; 3.131330e-01 ];
Tc_8  = [ -1.012656e+02 ; -5.827801e+01 ; 2.827689e+02 ];
omc_error_8 = [ 8.176239e-03 ; 6.833098e-03 ; 1.527988e-02 ];
Tc_error_8  = [ 2.973951e+00 ; 2.560268e+00 ; 2.408713e+00 ];

%-- Image #9:
omc_9 = [ -1.580870e+00 ; -1.875126e+00 ; -1.231071e+00 ];
Tc_9  = [ 1.531188e+01 ; -3.215762e+01 ; 3.398780e+02 ];
omc_error_9 = [ 5.591434e-03 ; 1.131345e-02 ; 1.334311e-02 ];
Tc_error_9  = [ 3.505538e+00 ; 3.012477e+00 ; 3.176198e+00 ];

%-- Image #10:
omc_10 = [ 1.838501e+00 ; 1.801292e+00 ; 5.640481e-01 ];
Tc_10  = [ -2.187983e+01 ; -7.492594e+01 ; 2.718096e+02 ];
omc_error_10 = [ 9.348902e-03 ; 7.065007e-03 ; 1.320680e-02 ];
Tc_error_10  = [ 2.818152e+00 ; 2.376097e+00 ; 2.256128e+00 ];

%-- Image #11:
omc_11 = [ 1.919607e+00 ; 1.912325e+00 ; -1.974008e-01 ];
Tc_11  = [ -1.270361e+02 ; -1.169230e+02 ; 4.751181e+02 ];
omc_error_11 = [ 7.436329e-03 ; 1.009425e-02 ; 1.541332e-02 ];
Tc_error_11  = [ 4.933447e+00 ; 4.254213e+00 ; 3.822722e+00 ];

%-- Image #12:
omc_12 = [ -2.161662e+00 ; -2.141878e+00 ; 1.761136e-01 ];
Tc_12  = [ -7.602870e+01 ; -7.411287e+01 ; 4.038705e+02 ];
omc_error_12 = [ 9.222376e-03 ; 9.511151e-03 ; 1.938494e-02 ];
Tc_error_12  = [ 4.157146e+00 ; 3.565237e+00 ; 3.241347e+00 ];

%-- Image #13:
omc_13 = [ -1.927497e+00 ; -1.860430e+00 ; -8.923259e-01 ];
Tc_13  = [ -1.095882e+02 ; 1.073023e+01 ; 3.714452e+02 ];
omc_error_13 = [ 6.618498e-03 ; 1.004496e-02 ; 1.475825e-02 ];
Tc_error_13  = [ 3.806638e+00 ; 3.333586e+00 ; 3.500313e+00 ];

%-- Image #14:
omc_14 = [ -1.264499e+00 ; -1.672136e+00 ; 8.083114e-01 ];
Tc_14  = [ -1.805386e+01 ; -8.536109e+01 ; 4.632853e+02 ];
omc_error_14 = [ 8.726660e-03 ; 8.960100e-03 ; 9.730779e-03 ];
Tc_error_14  = [ 4.732103e+00 ; 4.076114e+00 ; 2.680989e+00 ];

%-- Image #15:
omc_15 = [ 1.545028e+00 ; 2.443433e+00 ; -4.168895e-01 ];
Tc_15  = [ -1.096019e+02 ; -1.561817e+02 ; 5.352791e+02 ];
omc_error_15 = [ 5.568175e-03 ; 1.245153e-02 ; 1.739985e-02 ];
Tc_error_15  = [ 5.575514e+00 ; 4.796183e+00 ; 4.050094e+00 ];

%-- Image #16:
omc_16 = [ -1.860427e+00 ; -1.833497e+00 ; 9.735529e-02 ];
Tc_16  = [ -6.952822e+01 ; -1.105059e+00 ; 5.283812e+02 ];
omc_error_16 = [ 7.750633e-03 ; 1.033859e-02 ; 1.516748e-02 ];
Tc_error_16  = [ 5.410836e+00 ; 4.662045e+00 ; 3.842681e+00 ];

